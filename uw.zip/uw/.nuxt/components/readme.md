# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ItemCards>` | `<item-cards>` (components/ItemCards.vue)
- `<ItemDetalis>` | `<item-detalis>` (components/ItemDetalis.vue)
- `<ItemFeedback>` | `<item-feedback>` (components/ItemFeedback.vue)
- `<ItemProductCard>` | `<item-product-card>` (components/ItemProductCard.vue)
- `<ItemReviews>` | `<item-reviews>` (components/ItemReviews.vue)
- `<ItemWedding>` | `<item-wedding>` (components/ItemWedding.vue)
- `<MainBanner>` | `<main-banner>` (components/MainBanner.vue)
- `<MainBody>` | `<main-body>` (components/MainBody.vue)
- `<MainCards>` | `<main-cards>` (components/MainCards.vue)
- `<MainCategory>` | `<main-category>` (components/MainCategory.vue)
- `<MainFooter>` | `<main-footer>` (components/MainFooter.vue)
- `<MainHeader>` | `<main-header>` (components/MainHeader.vue)
- `<MainNews>` | `<main-news>` (components/MainNews.vue)
- `<MainSubscribe>` | `<main-subscribe>` (components/MainSubscribe.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
