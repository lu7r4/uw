export { default as ItemCards } from '../../components/ItemCards.vue'
export { default as ItemDetalis } from '../../components/ItemDetalis.vue'
export { default as ItemFeedback } from '../../components/ItemFeedback.vue'
export { default as ItemProductCard } from '../../components/ItemProductCard.vue'
export { default as ItemReviews } from '../../components/ItemReviews.vue'
export { default as ItemWedding } from '../../components/ItemWedding.vue'
export { default as MainBanner } from '../../components/MainBanner.vue'
export { default as MainBody } from '../../components/MainBody.vue'
export { default as MainCards } from '../../components/MainCards.vue'
export { default as MainCategory } from '../../components/MainCategory.vue'
export { default as MainFooter } from '../../components/MainFooter.vue'
export { default as MainHeader } from '../../components/MainHeader.vue'
export { default as MainNews } from '../../components/MainNews.vue'
export { default as MainSubscribe } from '../../components/MainSubscribe.vue'
export { default as NuxtLogo } from '../../components/NuxtLogo.vue'
export { default as Tutorial } from '../../components/Tutorial.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
